from django.shortcuts import render,redirect,reverse
from . import forms,models
from django.db.models import Sum
from django.contrib.auth.models import Group
from django.http import HttpResponseRedirect
from django.contrib.auth.decorators import login_required,user_passes_test
from django.conf import settings
from datetime import date, timedelta
from quiz import models as QMODEL
from teacher import models as TMODEL


#for showing signup/login button for student
def studentclick_view(request):
    if request.user.is_authenticated:
        return HttpResponseRedirect('afterlogin')
    return render(request,'student/studentclick.html')

def student_signup_view(request):
    userForm=forms.StudentUserForm()
    studentForm=forms.StudentForm()
    mydict={'userForm':userForm,'studentForm':studentForm}
    if request.method=='POST':
        userForm=forms.StudentUserForm(request.POST)
        studentForm=forms.StudentForm(request.POST,request.FILES)
        if userForm.is_valid() and studentForm.is_valid():
            user=userForm.save()
            user.set_password(user.password)
            user.save()
            student=studentForm.save(commit=False)
            student.user=user
            student.save()
            my_student_group = Group.objects.get_or_create(name='STUDENT')
            my_student_group[0].user_set.add(user)
        return HttpResponseRedirect('studentlogin')
    return render(request,'student/studentsignup.html',context=mydict)

def is_student(user):
    return user.groups.filter(name='STUDENT').exists()

@login_required(login_url='studentlogin')
@user_passes_test(is_student)
def student_dashboard_view(request):
    # Get student object for profile picture
    student = models.Student.objects.get(user_id=request.user.id)
    
    dict={
    'student': student,
    'total_course':QMODEL.Course.objects.all().count(),
    'total_question':QMODEL.Question.objects.all().count(),
    }
    return render(request,'student/student_dashboard.html',context=dict)

@login_required(login_url='studentlogin')
@user_passes_test(is_student)
def student_exam_view(request):
    student = models.Student.objects.get(user_id=request.user.id)
    courses = QMODEL.Course.objects.all()
    
    # Check payment access for each course
    courses_with_access = []
    for course in courses:
        course_info = {
            'course': course,
            'has_access': True,  # Default for free courses
            'is_paid': course.is_paid,
            'price': course.price
        }
        
        # If it's a paid course, check if student has paid
        if course.is_paid and course.price > 0:
            try:
                exam_access = QMODEL.ExamAccess.objects.get(
                    student=student, 
                    course=course, 
                    access_granted=True
                )
                course_info['has_access'] = True
            except QMODEL.ExamAccess.DoesNotExist:
                course_info['has_access'] = False
        
        courses_with_access.append(course_info)
    
    return render(request,'student/student_exam.html',{
        'courses_with_access': courses_with_access, 
        'student': student
    })

@login_required(login_url='studentlogin')
@user_passes_test(is_student)
def take_exam_view(request,pk):
    course=QMODEL.Course.objects.get(id=pk)
    student = models.Student.objects.get(user_id=request.user.id)
    
    # Check if it's a paid course and student has access
    if course.is_paid and course.price > 0:
        try:
            exam_access = QMODEL.ExamAccess.objects.get(
                student=student, 
                course=course, 
                access_granted=True
            )
        except QMODEL.ExamAccess.DoesNotExist:
            # Redirect to payment page
            return redirect('pay-exam', course_id=course.id)
    
    # Check attempt limit
    previous_attempts = QMODEL.Result.objects.filter(student=student, exam=course).count()
    
    # If attempt limit is set (not 0) and student has reached the limit
    if course.attempt_limit > 0 and previous_attempts >= course.attempt_limit:
        return render(request,'student/exam_limit_reached.html',{
            'course':course,
            'attempt_limit':course.attempt_limit,
            'attempts_made':previous_attempts
        })
    
    total_questions=QMODEL.Question.objects.all().filter(course=course).count()
    questions=QMODEL.Question.objects.all().filter(course=course)
    total_marks=0
    for q in questions:
        total_marks=total_marks + q.marks
    
    return render(request,'student/take_exam.html',{
        'course':course,
        'total_questions':total_questions,
        'total_marks':total_marks,
        'attempts_made':previous_attempts,
        'attempt_limit':course.attempt_limit
    })

@login_required(login_url='studentlogin')
@user_passes_test(is_student)
def start_exam_view(request,pk):
    course=QMODEL.Course.objects.get(id=pk)
    
    # Check attempt limit before starting exam
    student = models.Student.objects.get(user_id=request.user.id)
    previous_attempts = QMODEL.Result.objects.filter(student=student, exam=course).count()
    
    # If attempt limit is set (not 0) and student has reached the limit
    if course.attempt_limit > 0 and previous_attempts >= course.attempt_limit:
        return render(request,'student/exam_limit_reached.html',{
            'course':course,
            'attempt_limit':course.attempt_limit,
            'attempts_made':previous_attempts
        })
    
    questions=QMODEL.Question.objects.all().filter(course=course)
    if request.method=='POST':
        pass
    response= render(request,'student/ssc_exam_interface.html',{'course':course,'questions':questions})
    response.set_cookie('course_id',course.id)
    return response


@login_required(login_url='studentlogin')
@user_passes_test(is_student)
def calculate_marks_view(request):
    # Get course_id from cookies or POST data
    course_id = request.COOKIES.get('course_id')
    if not course_id and request.method == 'POST':
        # Try to get from POST data if cookies don't work
        course_id = request.POST.get('course_id')
    
    if course_id is not None:
        course=QMODEL.Course.objects.get(id=course_id)
        
        total_marks=0
        questions=QMODEL.Question.objects.all().filter(course=course)
        student = models.Student.objects.get(user_id=request.user.id)
        
        # Create result first
        result = QMODEL.Result()
        result.marks=0  # Will update later
        result.exam=course
        result.student=student
        result.save()
        
        # Process each question and save student answers
        for i in range(len(questions)):
            # Try to get answer from cookies first, then from POST data
            selected_ans = request.COOKIES.get(str(i+1))
            if not selected_ans and request.method == 'POST':
                selected_ans = request.POST.get(str(i+1))
            
            actual_answer = questions[i].answer
            
            # Debug: Print values for debugging
            print(f"Question {i+1}:")
            print(f"  Selected Answer: '{selected_ans}'")
            print(f"  Actual Answer: '{actual_answer}'")
            print(f"  Question Marks: {questions[i].marks}")
            print(f"  Match: {selected_ans == actual_answer}")
            
            # Save student answer to database
            student_answer = QMODEL.StudentAnswer()
            student_answer.student = student
            student_answer.question = questions[i]
            student_answer.result = result
            student_answer.selected_answer = selected_ans
            student_answer.save()
            
            # Calculate marks - check for both exact match and None handling
            if selected_ans and selected_ans == actual_answer:
                total_marks = total_marks + questions[i].marks
                print(f"  Added {questions[i].marks} marks. Total: {total_marks}")
            else:
                print(f"  No marks added. Selected: '{selected_ans}', Actual: '{actual_answer}'")
        
        # Update result with final marks
        result.marks = total_marks
        result.save()

        return HttpResponseRedirect('view-result')



@login_required(login_url='studentlogin')
@user_passes_test(is_student)
def view_result_view(request):
    student = models.Student.objects.get(user_id=request.user.id)
    courses=QMODEL.Course.objects.all()
    return render(request,'student/view_result.html',{'courses':courses, 'student':student})
    

@login_required(login_url='studentlogin')
@user_passes_test(is_student)
def check_marks_view(request,pk):
    course=QMODEL.Course.objects.get(id=pk)
    student = models.Student.objects.get(user_id=request.user.id)
    results= QMODEL.Result.objects.all().filter(exam=course).filter(student=student)
    
    # Check if student has taken the exam
    if not results.exists():
        # Student hasn't taken the exam yet, redirect to exam page with message
        return render(request,'student/exam_not_taken.html',{
            'course':course,
            'message': f'You need to take the "{course.course_name}" exam first to view your results.',
            'exam_url': f'/student/start-exam/{course.id}'
        })
    
    # Get questions with explanations if show_solution is enabled
    questions_with_explanations = None
    if course.show_solution:
        questions = QMODEL.Question.objects.all().filter(course=course)
        questions_with_explanations = []
        
        # Get the latest result for this student and course
        latest_result = results.order_by('-date').first()
        
        for question in questions:
            # Get student answer from database
            student_answer_obj = None
            if latest_result:
                try:
                    student_answer_obj = QMODEL.StudentAnswer.objects.get(
                        student=student, 
                        question=question, 
                        result=latest_result
                    )
                    question.student_answer = student_answer_obj.selected_answer
                except QMODEL.StudentAnswer.DoesNotExist:
                    question.student_answer = None
            else:
                question.student_answer = None
            
            questions_with_explanations.append(question)
    
    return render(request,'student/check_marks.html',{
        'results':results,
        'course':course,
        'questions_with_explanations':questions_with_explanations,
        'show_solution':course.show_solution
    })

@login_required(login_url='studentlogin')
@user_passes_test(is_student)
def student_marks_view(request):
    courses=QMODEL.Course.objects.all()
    return render(request,'student/student_marks.html',{'courses':courses})
  