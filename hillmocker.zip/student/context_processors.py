from . import models

def student_context(request):
    """
    Context processor to add student object to all templates
    """
    context = {}
    
    if request.user.is_authenticated:
        try:
            # Check if user is a student
            if request.user.groups.filter(name='STUDENT').exists():
                student = models.Student.objects.get(user=request.user)
                context['student'] = student
        except models.Student.DoesNotExist:
            # Student object doesn't exist, create one
            pass
    
    return context
