from django import forms
from django.contrib.auth.models import User
from . import models

class ContactusForm(forms.Form):
    Name = forms.CharField(max_length=30)
    Email = forms.EmailField()
    Message = forms.CharField(max_length=500,widget=forms.Textarea(attrs={'rows': 3, 'cols': 30}))

class TeacherSalaryForm(forms.Form):
    salary=forms.IntegerField()

class CourseForm(forms.ModelForm):
    class Meta:
        model=models.Course
        fields=['course_name','question_number','total_marks','attempt_limit','show_solution','exam_duration','price','is_paid']
        widgets = {
            'attempt_limit': forms.NumberInput(attrs={'min': '0', 'placeholder': '0 = Unlimited attempts'}),
            'show_solution': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'exam_duration': forms.NumberInput(attrs={'min': '1', 'placeholder': 'Duration in minutes'}),
            'price': forms.NumberInput(attrs={'min': '0', 'step': '0.01', 'placeholder': 'Enter price in rupees (0 = Free)'}),
            'is_paid': forms.CheckboxInput(attrs={'class': 'form-check-input'})
        }

class QuestionForm(forms.ModelForm):
    
    #this will show dropdown __str__ method course model is shown on html so override it
    #to_field_name this will fetch corresponding value  user_id present in course model and return it
    courseID=forms.ModelChoiceField(queryset=models.Course.objects.all(),empty_label="Course Name", to_field_name="id")
    class Meta:
        model=models.Question
        fields=['marks','question','option1','option2','option3','option4','answer','explanation']
        widgets = {
            'question': forms.Textarea(attrs={'rows': 3, 'cols': 50}),
            'explanation': forms.Textarea(attrs={'rows': 4, 'cols': 50, 'placeholder': 'Detailed explanation for the correct answer (optional)'})
        }

class HomeBannerForm(forms.ModelForm):
    class Meta:
        model = models.HomeBanner
        fields = ['title', 'description', 'banner_image', 'is_active']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter banner title'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Enter banner description (optional)'}),
            'banner_image': forms.FileInput(attrs={'class': 'form-control', 'accept': '.png,.jpg,.jpeg'}),
            'is_active': forms.CheckboxInput(attrs={'class': 'form-check-input'})
        }
