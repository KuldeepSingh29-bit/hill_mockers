from django.core.management.base import BaseCommand
from quiz.models import Course, Result
from student.models import Student

class Command(BaseCommand):
    help = 'Fix student attempts to respect course attempt limits'

    def handle(self, *args, **options):
        courses = Course.objects.all()
        
        for course in courses:
            if course.attempt_limit > 0:  # Only fix courses with attempt limits
                students = Student.objects.all()
                
                for student in students:
                    # Get all results for this student and course
                    results = Result.objects.filter(student=student, exam=course).order_by('-date')
                    
                    if results.count() > course.attempt_limit:
                        # Keep only the latest attempts up to the limit
                        results_to_keep = results[:course.attempt_limit]
                        results_to_delete = results[course.attempt_limit:]
                        
                        deleted_count = len(results_to_delete)
                        for result in results_to_delete:
                            result.delete()
                        
                        if deleted_count > 0:
                            self.stdout.write(
                                self.style.SUCCESS(
                                    f'Fixed {student.user.first_name} {student.user.last_name} '
                                    f'for {course.course_name}: removed {deleted_count} excess attempts'
                                )
                            )
        
        self.stdout.write(self.style.SUCCESS('Successfully fixed all student attempts!'))
