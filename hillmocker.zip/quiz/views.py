from django.shortcuts import render,redirect,reverse
from . import forms,models
from django.db.models import Sum
from django.contrib.auth.models import Group
from django.http import HttpResponseRedirect
from django.contrib.auth.decorators import login_required,user_passes_test
from django.conf import settings
from datetime import date, timedelta, datetime
import time
from django.db.models import Q
from django.core.mail import send_mail
from teacher import models as TMODEL
from student import models as SMODEL
from teacher import forms as TFORM
from student import forms as SFORM
from django.contrib.auth.models import User



def home_view(request):
    if request.user.is_authenticated:
        return HttpResponseRedirect('afterlogin')
    
    # Get active banners for home page
    active_banners = models.HomeBanner.objects.filter(is_active=True).order_by('-created_date')
    
    return render(request,'quiz/index.html', {'banners': active_banners})


def is_teacher(user):
    return user.groups.filter(name='TEACHER').exists()

def is_student(user):
    return user.groups.filter(name='STUDENT').exists()

def afterlogin_view(request):
    if is_student(request.user):      
        return redirect('student/student-dashboard')
                
    elif is_teacher(request.user):
        accountapproval=TMODEL.Teacher.objects.all().filter(user_id=request.user.id,status=True)
        if accountapproval:
            return redirect('teacher/teacher-dashboard')
        else:
            return render(request,'teacher/teacher_wait_for_approval.html')
    else:
        return redirect('admin-dashboard')



def adminclick_view(request):
    if request.user.is_authenticated:
        return HttpResponseRedirect('afterlogin')
    return HttpResponseRedirect('adminlogin')


@login_required(login_url='adminlogin')
def admin_dashboard_view(request):
    dict={
    'total_student':SMODEL.Student.objects.all().count(),
    'total_teacher':TMODEL.Teacher.objects.all().filter(status=True).count(),
    'total_course':models.Course.objects.all().count(),
    'total_question':models.Question.objects.all().count(),
    }
    return render(request,'quiz/admin_dashboard.html',context=dict)

@login_required(login_url='adminlogin')
def admin_teacher_view(request):
    dict={
    'total_teacher':TMODEL.Teacher.objects.all().filter(status=True).count(),
    'pending_teacher':TMODEL.Teacher.objects.all().filter(status=False).count(),
    'salary':TMODEL.Teacher.objects.all().filter(status=True).aggregate(Sum('salary'))['salary__sum'],
    }
    return render(request,'quiz/admin_teacher.html',context=dict)

@login_required(login_url='adminlogin')
def admin_view_teacher_view(request):
    teachers= TMODEL.Teacher.objects.all().filter(status=True)
    return render(request,'quiz/admin_view_teacher.html',{'teachers':teachers})


@login_required(login_url='adminlogin')
def update_teacher_view(request,pk):
    teacher=TMODEL.Teacher.objects.get(id=pk)
    user=TMODEL.User.objects.get(id=teacher.user_id)
    userForm=TFORM.TeacherUserForm(instance=user)
    teacherForm=TFORM.TeacherForm(request.FILES,instance=teacher)
    mydict={'userForm':userForm,'teacherForm':teacherForm}
    if request.method=='POST':
        userForm=TFORM.TeacherUserForm(request.POST,instance=user)
        teacherForm=TFORM.TeacherForm(request.POST,request.FILES,instance=teacher)
        if userForm.is_valid() and teacherForm.is_valid():
            user=userForm.save()
            user.set_password(user.password)
            user.save()
            teacherForm.save()
            return redirect('admin-view-teacher')
    return render(request,'quiz/update_teacher.html',context=mydict)



@login_required(login_url='adminlogin')
def delete_teacher_view(request,pk):
    teacher=TMODEL.Teacher.objects.get(id=pk)
    user=User.objects.get(id=teacher.user_id)
    user.delete()
    teacher.delete()
    return HttpResponseRedirect('/admin-view-teacher')




@login_required(login_url='adminlogin')
def admin_view_pending_teacher_view(request):
    teachers= TMODEL.Teacher.objects.all().filter(status=False)
    return render(request,'quiz/admin_view_pending_teacher.html',{'teachers':teachers})


@login_required(login_url='adminlogin')
def approve_teacher_view(request,pk):
    teacherSalary=forms.TeacherSalaryForm()
    if request.method=='POST':
        teacherSalary=forms.TeacherSalaryForm(request.POST)
        if teacherSalary.is_valid():
            teacher=TMODEL.Teacher.objects.get(id=pk)
            teacher.salary=teacherSalary.cleaned_data['salary']
            teacher.status=True
            teacher.save()
        else:
            print("form is invalid")
        return HttpResponseRedirect('/admin-view-pending-teacher')
    return render(request,'quiz/salary_form.html',{'teacherSalary':teacherSalary})

@login_required(login_url='adminlogin')
def reject_teacher_view(request,pk):
    teacher=TMODEL.Teacher.objects.get(id=pk)
    user=User.objects.get(id=teacher.user_id)
    user.delete()
    teacher.delete()
    return HttpResponseRedirect('/admin-view-pending-teacher')

@login_required(login_url='adminlogin')
def admin_view_teacher_salary_view(request):
    teachers= TMODEL.Teacher.objects.all().filter(status=True)
    return render(request,'quiz/admin_view_teacher_salary.html',{'teachers':teachers})




@login_required(login_url='adminlogin')
def admin_student_view(request):
    dict={
    'total_student':SMODEL.Student.objects.all().count(),
    }
    return render(request,'quiz/admin_student.html',context=dict)

@login_required(login_url='adminlogin')
def admin_view_student_view(request):
    students= SMODEL.Student.objects.all()
    return render(request,'quiz/admin_view_student.html',{'students':students})



@login_required(login_url='adminlogin')
def update_student_view(request,pk):
    student=SMODEL.Student.objects.get(id=pk)
    user=SMODEL.User.objects.get(id=student.user_id)
    userForm=SFORM.StudentUserForm(instance=user)
    studentForm=SFORM.StudentForm(request.FILES,instance=student)
    mydict={'userForm':userForm,'studentForm':studentForm}
    if request.method=='POST':
        userForm=SFORM.StudentUserForm(request.POST,instance=user)
        studentForm=SFORM.StudentForm(request.POST,request.FILES,instance=student)
        if userForm.is_valid() and studentForm.is_valid():
            user=userForm.save()
            user.set_password(user.password)
            user.save()
            studentForm.save()
            return redirect('admin-view-student')
    return render(request,'quiz/update_student.html',context=mydict)



@login_required(login_url='adminlogin')
def delete_student_view(request,pk):
    student=SMODEL.Student.objects.get(id=pk)
    user=User.objects.get(id=student.user_id)
    user.delete()
    student.delete()
    return HttpResponseRedirect('/admin-view-student')


@login_required(login_url='adminlogin')
def admin_course_view(request):
    return render(request,'quiz/admin_course.html')


@login_required(login_url='adminlogin')
def admin_add_course_view(request):
    courseForm=forms.CourseForm()
    if request.method=='POST':
        courseForm=forms.CourseForm(request.POST)
        if courseForm.is_valid():        
            courseForm.save()
        else:
            print("form is invalid")
        return HttpResponseRedirect('/admin-view-course')
    return render(request,'quiz/admin_add_course.html',{'courseForm':courseForm})


@login_required(login_url='adminlogin')
def admin_view_course_view(request):
    courses = models.Course.objects.all()
    return render(request,'quiz/admin_view_course.html',{'courses':courses})

@login_required(login_url='adminlogin')
def delete_course_view(request,pk):
    course=models.Course.objects.get(id=pk)
    course.delete()
    return HttpResponseRedirect('/admin-view-course')



@login_required(login_url='adminlogin')
def admin_question_view(request):
    return render(request,'quiz/admin_question.html')


@login_required(login_url='adminlogin')
def admin_add_question_view(request):
    questionForm=forms.QuestionForm()
    if request.method=='POST':
        questionForm=forms.QuestionForm(request.POST)
        if questionForm.is_valid():
            question=questionForm.save(commit=False)
            course=models.Course.objects.get(id=request.POST.get('courseID'))
            question.course=course
            question.save()       
        else:
            print("form is invalid")
        return HttpResponseRedirect('/admin-view-question')
    return render(request,'quiz/admin_add_question.html',{'questionForm':questionForm})


@login_required(login_url='adminlogin')
def admin_view_question_view(request):
    courses= models.Course.objects.all()
    return render(request,'quiz/admin_view_question.html',{'courses':courses})

@login_required(login_url='adminlogin')
def view_question_view(request,pk):
    questions=models.Question.objects.all().filter(course_id=pk)
    return render(request,'quiz/view_question.html',{'questions':questions})

@login_required(login_url='adminlogin')
def delete_question_view(request,pk):
    question=models.Question.objects.get(id=pk)
    question.delete()
    return HttpResponseRedirect('/admin-view-question')

@login_required(login_url='adminlogin')
def admin_view_student_marks_view(request):
    students= SMODEL.Student.objects.all()
    return render(request,'quiz/admin_view_student_marks.html',{'students':students})

@login_required(login_url='adminlogin')
def admin_view_marks_view(request,pk):
    courses = models.Course.objects.all()
    response =  render(request,'quiz/admin_view_marks.html',{'courses':courses})
    response.set_cookie('student_id',str(pk))
    return response

@login_required(login_url='adminlogin')
def admin_check_marks_view(request,pk):
    course = models.Course.objects.get(id=pk)
    student_id = request.COOKIES.get('student_id')
    student= SMODEL.Student.objects.get(id=student_id)

    results= models.Result.objects.all().filter(exam=course).filter(student=student)
    return render(request,'quiz/admin_check_marks.html',{'results':results})
    




def aboutus_view(request):
    return render(request,'quiz/aboutus.html')

def contactus_view(request):
    sub = forms.ContactusForm()
    if request.method == 'POST':
        sub = forms.ContactusForm(request.POST)
        if sub.is_valid():
            email = sub.cleaned_data['Email']
            name=sub.cleaned_data['Name']
            message = sub.cleaned_data['Message']
            send_mail(str(name)+' || '+str(email),message,settings.EMAIL_HOST_USER, settings.EMAIL_RECEIVING_USER, fail_silently = False)
            return render(request, 'quiz/contactussuccess.html')
    return render(request, 'quiz/contactus.html', {'form':sub})

# Payment System Views
import razorpay
import json
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse

@login_required(login_url='studentlogin')
def pay_exam_view(request, course_id):
    try:
        course = models.Course.objects.get(id=course_id)
        student = SMODEL.Student.objects.get(user_id=request.user.id)
        
        # Check if already paid
        try:
            existing_access = models.ExamAccess.objects.get(
                student=student, 
                course=course, 
                access_granted=True
            )
            return redirect('take-exam', pk=course.id)
        except models.ExamAccess.DoesNotExist:
            pass
        
        # Create Razorpay client
        client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))
        
        # Create order
        amount = int(course.price * 100)  # Amount in paise
        order_data = {
            'amount': amount,
            'currency': 'INR',
            'receipt': f'order_{course.id}_{student.id}_{int(time.time())}',
            'payment_capture': 1
        }
        
        razorpay_order = client.order.create(data=order_data)
        
        # Create payment record
        payment = models.Payment.objects.create(
            student=student,
            course=course,
            amount=course.price,
            order_id=razorpay_order['id'],
            payment_status='pending'
        )
        
        context = {
            'course': course,
            'student': student,
            'payment': payment,
            'razorpay_order_id': razorpay_order['id'],
            'razorpay_key_id': settings.RAZORPAY_KEY_ID,
            'amount': amount,
        }
        
        return render(request, 'quiz/payment_page.html', context)
        
    except models.Course.DoesNotExist:
        return render(request, 'quiz/payment_error.html', {'error': 'Course not found'})
    except SMODEL.Student.DoesNotExist:
        return render(request, 'quiz/payment_error.html', {'error': 'Student profile not found'})
    except Exception as e:
        return render(request, 'quiz/payment_error.html', {'error': str(e)})

def initiate_payment(request, course_id):
    if not request.user.is_authenticated:
        return redirect('studentlogin')
    
    try:
        student = SMODEL.Student.objects.get(user=request.user)
        course = models.Course.objects.get(id=course_id)
        
        # Check if course is paid
        if not course.is_paid or course.price == 0:
            # Free course, grant access directly
            access, created = models.ExamAccess.objects.get_or_create(
                student=student,
                course=course,
                defaults={'access_granted': True}
            )
            return redirect('student-exam')
        
        # Check if already has access
        if models.ExamAccess.objects.filter(student=student, course=course, access_granted=True).exists():
            return redirect('student-exam')
        
        # Create Razorpay client
        client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))
        
        # Create order
        order_data = {
            'amount': int(course.price * 100),  # Amount in paise
            'currency': 'INR',
            'receipt': f'exam_{course_id}_{student.id}',
            'payment_capture': 1
        }
        
        order = client.order.create(data=order_data)
        
        # Create payment record
        payment = models.Payment.objects.create(
            student=student,
            course=course,
            amount=course.price,
            payment_id=order['id'],
            order_id=order['id'],
            status='pending'
        )
        
        context = {
            'course': course,
            'order': order,
            'razorpay_key_id': settings.RAZORPAY_KEY_ID,
            'payment': payment
        }
        
        return render(request, 'quiz/payment_page.html', context)
        
    except Exception as e:
        return render(request, 'quiz/payment_error.html', {'error': str(e)})

@csrf_exempt
def payment_success(request):
    if request.method == 'POST':
        try:
            # Get payment details from Razorpay
            payment_id = request.POST.get('razorpay_payment_id')
            order_id = request.POST.get('razorpay_order_id')
            signature = request.POST.get('razorpay_signature')
            
            # Verify payment signature
            client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))
            
            params_dict = {
                'razorpay_order_id': order_id,
                'razorpay_payment_id': payment_id,
                'razorpay_signature': signature
            }
            
            client.utility.verify_payment_signature(params_dict)
            
            # Update payment status
            payment = models.Payment.objects.get(order_id=order_id)
            payment.payment_id = payment_id
            payment.status = 'completed'
            payment.payment_gateway_response = params_dict
            payment.save()
            
            # Grant exam access
            models.ExamAccess.objects.create(
                student=payment.student,
                course=payment.course,
                payment=payment,
                access_granted=True
            )
            
            return render(request, 'quiz/payment_success.html', {'payment': payment})
            
        except Exception as e:
            return render(request, 'quiz/payment_error.html', {'error': str(e)})
    
    return redirect('student-exam')

@csrf_exempt
def payment_failure(request):
    return render(request, 'quiz/payment_failure.html')

# Banner Management Views
@login_required(login_url='adminlogin')
def admin_banner_view(request):
    banners = models.HomeBanner.objects.all()
    return render(request,'quiz/admin_banner.html',{'banners':banners})

@login_required(login_url='adminlogin')
def admin_add_banner_view(request):
    bannerForm = forms.HomeBannerForm()
    if request.method=='POST':
        bannerForm = forms.HomeBannerForm(request.POST, request.FILES)
        if bannerForm.is_valid():
            bannerForm.save()
        else:
            print("form is invalid")
        return HttpResponseRedirect('/admin-banner')
    return render(request,'quiz/admin_add_banner.html',{'bannerForm':bannerForm})

@login_required(login_url='adminlogin')
def admin_view_banner_view(request):
    banners = models.HomeBanner.objects.all()
    return render(request,'quiz/admin_view_banner.html',{'banners':banners})

@login_required(login_url='adminlogin')
def delete_banner_view(request,pk):
    banner = models.HomeBanner.objects.get(id=pk)
    banner.delete()
    return HttpResponseRedirect('/admin-view-banner')

@login_required(login_url='adminlogin')
def update_banner_view(request,pk):
    banner = models.HomeBanner.objects.get(id=pk)
    bannerForm = forms.HomeBannerForm(instance=banner)
    if request.method=='POST':
        bannerForm = forms.HomeBannerForm(request.POST, request.FILES, instance=banner)
        if bannerForm.is_valid():
            bannerForm.save()
        return HttpResponseRedirect('/admin-view-banner')
    return render(request,'quiz/admin_update_banner.html',{'bannerForm':bannerForm})


