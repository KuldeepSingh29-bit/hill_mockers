from django.db import models

from student.models import Student
class Course(models.Model):
   course_name = models.CharField(max_length=50)
   question_number = models.PositiveIntegerField()
   total_marks = models.PositiveIntegerField()
   attempt_limit = models.PositiveIntegerField(default=0, help_text="0 means unlimited attempts")
   show_solution = models.BooleanField(default=False, help_text="Show detailed explanations after exam")
   exam_duration = models.PositiveIntegerField(default=60, help_text="Exam duration in minutes")
   price = models.DecimalField(max_digits=10, decimal_places=2, default=0.00, help_text="Exam entry fee in rupees (0 = Free)")
   is_paid = models.BooleanField(default=False, help_text="Is this a paid exam?")
   def __str__(self):
        return self.course_name

class Question(models.Model):
    course=models.ForeignKey(Course,on_delete=models.CASCADE)
    marks=models.PositiveIntegerField()
    question=models.CharField(max_length=600)
    option1=models.CharField(max_length=200)
    option2=models.CharField(max_length=200)
    option3=models.CharField(max_length=200)
    option4=models.CharField(max_length=200)
    cat=(('Option1','Option1'),('Option2','Option2'),('Option3','Option3'),('Option4','Option4'))
    answer=models.CharField(max_length=200,choices=cat)
    explanation=models.TextField(max_length=1000, blank=True, null=True, help_text="Detailed explanation for the correct answer")

class Result(models.Model):
    student = models.ForeignKey(Student,on_delete=models.CASCADE)
    exam = models.ForeignKey(Course,on_delete=models.CASCADE)
    marks = models.PositiveIntegerField()
    date = models.DateTimeField(auto_now=True)

class StudentAnswer(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    result = models.ForeignKey(Result, on_delete=models.CASCADE)
    selected_answer = models.CharField(max_length=200, choices=(('Option1','Option1'),('Option2','Option2'),('Option3','Option3'),('Option4','Option4')), null=True, blank=True)
    date = models.DateTimeField(auto_now=True)
    
    class Meta:
        unique_together = ('student', 'question', 'result')

class HomeBanner(models.Model):
    title = models.CharField(max_length=100, help_text="Banner title")
    description = models.TextField(max_length=500, blank=True, help_text="Banner description")
    banner_image = models.ImageField(upload_to='banners/', help_text="Upload PNG image for home page banner")
    is_active = models.BooleanField(default=True, help_text="Show this banner on home page")
    created_date = models.DateTimeField(auto_now_add=True)
    updated_date = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.title
    
    class Meta:
        ordering = ['-created_date']

class Payment(models.Model):
    PAYMENT_STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
        ('refunded', 'Refunded'),
    ]
    
    PAYMENT_METHOD_CHOICES = [
        ('razorpay', 'Razorpay'),
        ('stripe', 'Stripe'),
        ('paytm', 'Paytm'),
        ('upi', 'UPI'),
    ]
    
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    payment_id = models.CharField(max_length=100, unique=True)
    order_id = models.CharField(max_length=100, blank=True, null=True)
    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHOD_CHOICES, default='razorpay')
    status = models.CharField(max_length=20, choices=PAYMENT_STATUS_CHOICES, default='pending')
    transaction_date = models.DateTimeField(auto_now_add=True)
    payment_gateway_response = models.JSONField(blank=True, null=True)
    
    def __str__(self):
        return f"{self.student.user.first_name} - {self.course.course_name} - ₹{self.amount}"
    
    class Meta:
        ordering = ['-transaction_date']

class ExamAccess(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    payment = models.ForeignKey(Payment, on_delete=models.CASCADE, null=True, blank=True)
    access_granted = models.BooleanField(default=False)
    access_date = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField(null=True, blank=True)
    
    def __str__(self):
        return f"{self.student.user.first_name} - {self.course.course_name} Access"
    
    class Meta:
        unique_together = ('student', 'course')
        ordering = ['-access_date']

