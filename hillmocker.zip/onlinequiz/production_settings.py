# Production settings for InfinityFree hosting
import os
from .settings import *

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = False

# Add your InfinityFree domain here
ALLOWED_HOSTS = [
    'hillmockers.great-site.net',  # Your actual domain
    '127.0.0.1',
    'localhost',
]

# Database configuration for InfinityFree MySQL
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'if0_40025312_HillMocker',      # Your DB name
        'USER': 'if0_40025312',             # Your DB user
        'PASSWORD': 'O7WrBdgMfmoD2v6',  # Your account password
        'HOST': 'sql102.infinityfree.com',    # InfinityFree MySQL host
        'PORT': '3306',
        'OPTIONS': {
            'init_command': "SET sql_mode='STRICT_TRANS_TABLES'",
            'connect_timeout': 20,
            'read_timeout': 20,
            'write_timeout': 20,
        },
    }
}

# Static files configuration for InfinityFree
STATIC_URL = '/static/'
STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')

# Media files configuration
MEDIA_URL = '/media/'
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')

# Security settings for production
SECURE_BROWSER_XSS_FILTER = True
SECURE_CONTENT_TYPE_NOSNIFF = True
X_FRAME_OPTIONS = 'DENY'

# Session security
SESSION_COOKIE_SECURE = False  # Set to True if using HTTPS
CSRF_COOKIE_SECURE = False     # Set to True if using HTTPS

# Email configuration (optional)
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = 'your-email@gmail.com'  # Replace with your email
EMAIL_HOST_PASSWORD = 'your-app-password'  # Replace with your app password

# Razorpay settings (keep same as development)
RAZORPAY_KEY_ID = 'rzp_test_your_key_id'
RAZORPAY_KEY_SECRET = 'your_key_secret'

# Logging configuration
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'file': {
            'level': 'ERROR',
            'class': 'logging.FileHandler',
            'filename': os.path.join(BASE_DIR, 'django_errors.log'),
        },
    },
    'loggers': {
        'django': {
            'handlers': ['file'],
            'level': 'ERROR',
            'propagate': True,
        },
    },
}
