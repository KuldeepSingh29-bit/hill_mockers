#!/usr/bin/env python
import os
import django

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'onlinequiz.settings')
django.setup()

from django.contrib.auth.models import User

# Admin credentials
username = 'admin'
email = 'admin@quiz.com'
password = 'admin123'

# Check if admin user already exists
if User.objects.filter(username=username).exists():
    print(f"Admin user '{username}' already exists!")
    admin_user = User.objects.get(username=username)
    print(f"Username: {admin_user.username}")
    print(f"Email: {admin_user.email}")
else:
    # Create admin user
    admin_user = User.objects.create_superuser(
        username=username,
        email=email,
        password=password
    )
    print(f"Admin user created successfully!")
    print(f"Username: {username}")
    print(f"Email: {email}")
    print(f"Password: {password}")

print("\n" + "="*50)
print("ADMIN LOGIN CREDENTIALS:")
print("="*50)
print(f"Username: {username}")
print(f"Password: {password}")
print("="*50)
print("\nLogin URLs:")
print("Admin Panel: http://127.0.0.1:8000/admin/")
print("Admin Dashboard: http://127.0.0.1:8000/adminclick")
