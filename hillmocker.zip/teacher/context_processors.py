from . import models

def teacher_context(request):
    """
    Context processor to add teacher object to all templates
    """
    context = {}
    
    if request.user.is_authenticated:
        try:
            # Check if user is a teacher
            if request.user.groups.filter(name='TEACHER').exists():
                teacher = models.Teacher.objects.get(user=request.user)
                context['teacher'] = teacher
        except models.Teacher.DoesNotExist:
            # Teacher object doesn't exist, create one
            pass
    
    return context
